# Task Priority Predictor

A text classification model that predicts whether a task is **High**, **Medium**, or **Low** priority based on its description — built with scikit-learn.

## Problem

Given a short natural-language task description (e.g. "Fix production server outage"), predict its priority level. This is a common triage problem in project management and personal productivity tools.

## Approach

- **Features:** TF-IDF vectorization of task text (unigrams + bigrams, English stop words removed)
- **Model:** Logistic Regression (multi-class, scikit-learn)
- **Data:** 120 hand-labeled task descriptions, evenly split across High / Medium / Low
- **Evaluation:** 80/20 train-test split, stratified by class

## Results

- **Test accuracy:** 83%
- Performs best on clearly urgent language ("production outage", "deadline today") and clearly low-stakes language ("reorganize", "browse", "explore")

## Project Structure

```
task-priority-predictor/
├── data/
│   └── tasks.csv          # labeled dataset
├── model/
│   └── priority_model.pkl # trained pipeline (created after training)
├── train.py                # trains and evaluates the model
├── predict.py               # CLI demo for making predictions
└── requirements.txt
```

## How to Run

```bash
pip install -r requirements.txt

# Train the model
python train.py

# Predict a single task
python predict.py "Fix critical bug crashing the production app"

# Or run interactively
python predict.py
```

## Example

```
Task: Fix critical bug crashing the production app
Predicted priority: High
Confidence: {'High': 0.56, 'Low': 0.24, 'Medium': 0.2}
```

## Limitations & Next Steps

- Dataset is small (120 examples) and self-labeled, so it may not generalize to real-world task management data
- Could improve by:
  - Collecting labeled data from real task trackers (Jira, Trello exports)
  - Trying more complex models (SVM, gradient boosting) or word embeddings
  - Adding a simple web UI (Streamlit/Flask) instead of a CLI
  - Incorporating additional features like due dates or task category

## Author

Shreemoyee — built as a portfolio project for GDG club (AI/ML track) and internship prep.
