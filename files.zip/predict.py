"""
Task Priority Predictor - CLI demo.

Usage:
    python predict.py "Fix production server outage affecting all users"

Or run with no arguments for an interactive prompt.
"""

import sys
import joblib

MODEL_PATH = "model/priority_model.pkl"


def load_model():
    try:
        return joblib.load(MODEL_PATH)
    except FileNotFoundError:
        print("Model not found. Run 'python train.py' first.")
        sys.exit(1)


def predict(model, text):
    priority = model.predict([text])[0]
    proba = model.predict_proba([text])[0]
    classes = model.classes_
    confidence = dict(zip(classes, proba))
    return priority, confidence


def main():
    model = load_model()

    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
        priority, confidence = predict(model, text)
        print(f"\nTask: {text}")
        print(f"Predicted priority: {priority}")
        print("Confidence:", {k: round(v, 2) for k, v in confidence.items()})
    else:
        print("Task Priority Predictor (type 'quit' to exit)\n")
        while True:
            text = input("Enter a task description: ").strip()
            if text.lower() in ("quit", "exit"):
                break
            if not text:
                continue
            priority, confidence = predict(model, text)
            print(f"  -> Predicted priority: {priority}")
            print(f"     Confidence: {({k: round(v, 2) for k, v in confidence.items()})}\n")


if __name__ == "__main__":
    main()
